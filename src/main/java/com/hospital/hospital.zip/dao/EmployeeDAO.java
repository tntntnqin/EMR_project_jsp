package com.hospital.dao;

import org.apache.ibatis.session.SqlSession;

import com.hospital.vo.EmployeeVO;

public class EmployeeDAO {

	public static EmployeeDAO instance = new EmployeeDAO();
	
	private EmployeeDAO() { }
	
	public static EmployeeDAO getInstance() {
		return instance;
	}

	public EmployeeVO selectByEmployeeIdx(SqlSession mapper, int idx) {
		System.out.println("EmployeeDAO의 selectByEmployeeIdx() 메소드 실행 " );
		return (EmployeeVO) mapper.selectOne("selectByEmployeeIdx", idx);
	}
	
	
	
}
