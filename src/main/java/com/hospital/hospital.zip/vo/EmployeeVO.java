package com.hospital.vo;

public class EmployeeVO {
	
	private int employeeIdx;
	private String Id;
	private String password;
	private String name;
	private String gender;
	private int age;
	private String dpart;
	private String nurseT;
	private String doctorT;
	private String dnumber;
	private String enumber;
	
	public EmployeeVO () {}
	
	public EmployeeVO(int employeeIdx, String id, String password, String name, String gender, int age, String dpart,
			String nurseT, String doctorT, String dnumber, String enumber) {
		super();
		this.employeeIdx = employeeIdx;
		this.Id = id;
		this.password = password;
		this.name = name;
		this.gender = gender;
		this.age = age;
		this.dpart = dpart;
		this.nurseT = nurseT;
		this.doctorT = doctorT;
		this.dnumber = dnumber;
		this.enumber = enumber;
	}

	
	public int getEmployeeIdx() {
		return employeeIdx;
	}

	public void setEmployeeIdx(int employeeIdx) {
		this.employeeIdx = employeeIdx;
	}

	public String getId() {
		return Id;
	}

	public void setId(String id) {
		Id = id;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getDpart() {
		return dpart;
	}

	public void setDpart(String dpart) {
		this.dpart = dpart;
	}

	public String getNurseT() {
		return nurseT;
	}

	public void setNurseT(String nurseT) {
		this.nurseT = nurseT;
	}

	public String getDoctorT() {
		return doctorT;
	}

	public void setDoctorT(String doctorT) {
		this.doctorT = doctorT;
	}

	public String getDnumber() {
		return dnumber;
	}

	public void setDnumber(String dnumber) {
		this.dnumber = dnumber;
	}

	public String getEnumber() {
		return enumber;
	}

	public void setEnumber(String enumber) {
		this.enumber = enumber;
	}


	@Override
	public String toString() {
		return "EmployeeVO [employeeIdx=" + employeeIdx + ", Id=" + Id + ", password=" + password + ", name=" + name
				+ ", gender=" + gender + ", age=" + age + ", dpart=" + dpart + ", nurseT=" + nurseT + ", doctorT="
				+ doctorT + ", dnumber=" + dnumber + ", enumber=" + enumber + "]";
	}
	
	
	
}
