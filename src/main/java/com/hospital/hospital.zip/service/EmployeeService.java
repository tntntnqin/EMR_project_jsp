package com.hospital.service;

import org.apache.ibatis.session.SqlSession;

import com.hospital.dao.EmployeeDAO;
import com.hospital.mybatis.MySession;
import com.hospital.vo.EmployeeVO;

public class EmployeeService {

public static EmployeeService instance = new EmployeeService();
	
	private EmployeeService() { }
	
	public static EmployeeService getInstance() {
		return instance;
	}
	
	// loginOK.jsp에서 호출 사번과 비밀번호를 가지고 있는 vo를 얻어오기 위한 select
	public EmployeeVO selectByEmployeeIdx(int idx) {
		System.out.println("EmployeeService의 selectByEmployeeIdx()");
		SqlSession mapper = MySession.getSession();
		System.out.println("연결성공 : " + mapper);
		EmployeeVO vo =  EmployeeDAO.getInstance().selectByEmployeeIdx(mapper, idx);
		
		mapper.close();
		return vo;
	}
	
}